class FilmsController < ApplicationController
end
