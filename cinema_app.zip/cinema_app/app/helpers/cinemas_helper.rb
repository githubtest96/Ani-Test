module CinemasHelper
end
