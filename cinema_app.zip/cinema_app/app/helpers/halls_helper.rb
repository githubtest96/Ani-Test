module HallsHelper
end
