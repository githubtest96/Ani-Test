class Booking < ApplicationRecord
  belongs_to :session
end
