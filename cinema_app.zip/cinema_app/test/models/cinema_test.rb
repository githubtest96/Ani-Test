require 'test_helper'

class CinemaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
