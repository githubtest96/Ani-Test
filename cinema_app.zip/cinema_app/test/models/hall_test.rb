require 'test_helper'

class HallTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
